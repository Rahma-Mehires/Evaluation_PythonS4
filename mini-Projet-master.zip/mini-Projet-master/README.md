# mini-Projet

Le but de mon mini-projet est de créer une fonction qui permettra dans un dictionnaire de retrouver le type d'aliment et son poids associé.Cette fonction pourra ensuite être utilisée dans le cadre d'un autre projet qui serrait par exemple de nourrir des animaux dans un zoo avec ces aliments mais en respectant un certain poids par plateau d'aliment distribuer aux différents animaux.
